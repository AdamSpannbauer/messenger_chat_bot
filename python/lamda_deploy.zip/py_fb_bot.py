import requests
import json

access_token = "EAATDX51YsoQBAPFuidYbDGGhlc1JUpTBKDANZBRYljPZBL1VkFCHfu1crQ3kOwv0DJbQucVMc7l4u0WU0KRuiENr4A1IaqwrJLeZAZBw0lC6Km9satevh1xO7uqlM4uaZAG8zWaOCzGaVUrBubuCeGaC9ZCPDksXgs6EsBKRTswgZDZD"
verify_token = "tonks8675309"

def send_message(send_id, msg_txt):

    params  = {"access_token": access_token}
    headers = {"Content-Type": "application/json"}
    data = json.dumps({"recipient": {"id": send_id},
                       "message": {"text": msg_txt}})
                       
    r = requests.post("https://graph.facebook.com/v2.6/me/messages", params=params, headers=headers, data=data)
    
    if r.status_code != 200:
        print(r.status_code)
        print(r.text)


def lambda_handler(event, context):
    print(event)

    #process GET
    try:
        v_token = str(event[u'params'][u'querystring'][u'hub.verify_token'])
        challenge = str(event[u'params'][u'querystring'][u'hub.challenge'])
        if (verify_token == v_token):
            return(int(challenge))
    #process POST
    except:
        messaging_event = event['body-json']['entry'][0]['messaging'][0]
        msg_txt   = messaging_event['message']['text']
        sender_id = messaging_event['sender']['id']
        print(msg_txt)
        send_message(sender_id, msg_txt)
        